package com.example.universityadmissionscommittee.service;

import com.example.universityadmissionscommittee.data.ExamResult;
import com.example.universityadmissionscommittee.repository.ExamResultRepository;
import org.springframework.stereotype.Service;

@Service
public class ExamResultService  extends AbstractCrudService<ExamResult, Long, ExamResultRepository>{
    protected ExamResultService(ExamResultRepository repository) {
        super(repository);
    }
}
