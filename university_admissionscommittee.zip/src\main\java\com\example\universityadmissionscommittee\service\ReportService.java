package com.example.universityadmissionscommittee.service;
import com.example.universityadmissionscommittee.repository.ApplicantRepository;
import com.example.universityadmissionscommittee.repository.SpecialtyRepository;


public class ReportService {

    public ApplicantRepository applicantRepository;

    public SpecialtyRepository specialtyRepository;

    public SpecialtyService specialtyService;


}
