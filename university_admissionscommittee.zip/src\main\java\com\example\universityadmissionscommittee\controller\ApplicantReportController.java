package com.example.universityadmissionscommittee.controller;

import com.example.universityadmissionscommittee.service.SpecialtyService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/applicantReport")
public class ApplicantReportController {
    public SpecialtyService specialtyService;

    public ApplicantReportController(SpecialtyService specialtyService) {
        this.specialtyService = specialtyService;
    }

    @GetMapping("/")
    public String showForm(HttpSession session) {
        session.setAttribute("specialties", specialtyService.findAll());
        return "applicantsReport";
    }


}
