package com.example.universityadmissionscommittee.repository;

import com.example.universityadmissionscommittee.data.Specialty;
import com.example.universityadmissionscommittee.data.enums.SpecialtyType;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface SpecialtyRepository extends JpaRepository<Specialty, Long> {

    Optional<Specialty> findBySpecialtyType(SpecialtyType specialtyType);

    Optional<Specialty> findByName(String name);

}
