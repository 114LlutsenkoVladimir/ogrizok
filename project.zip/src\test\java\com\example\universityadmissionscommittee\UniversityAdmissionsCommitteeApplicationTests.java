package com.example.universityadmissionscommittee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniversityAdmissionsCommitteeApplicationTests {

    @Test
    void contextLoads() {
    }

}
